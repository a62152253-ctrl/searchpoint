@echo off
setlocal enabledelayedexpansion
title PROJECT NEXUS - Local Autonomous File Intelligence
color 0b

echo ===================================================================
echo   PROJECT NEXUS v2.5 - Local Autonomous File Intelligence ^& AI
echo ===================================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
  color 0c
  echo [BLAD] Node.js nie zostal znaleziony w sciezce PATH!
  echo Pobierz i zainstaluj Node.js v18+ ze strony: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

if not exist node_modules (
  echo [NEXUS] Pierwsze uruchomienie - instalowanie zaleznosci npm...
  call npm install
  if %ERRORLEVEL% neq 0 (
    echo [BLAD] Nie udalo sie zainstalowac pakietow npm.
    pause
    exit /b 1
  )
)

echo [NEXUS] Sprawdzanie uslugi Lokalne AI...
where ollama >nul 2>nul
if %ERRORLEVEL% equ 0 (
  echo [NEXUS] Wykryto silnik Lokalne AI. Sprawdzanie statusu uslugi...
  start /b ollama serve >nul 2>nul
) else (
  echo [INFO] Silnik Lokalne AI jest gotowy do konfiguracji w aplikacji.
)

echo.
echo [NEXUS] Uruchamianie serwera (port 3001) oraz interfejsu (port 5173)...
echo [NEXUS] Otwieram przegladarke: http://localhost:5173
echo.
start http://localhost:5173

npm run dev
pause
