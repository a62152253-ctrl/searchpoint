Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Detect application directory
appDir = ""
If fso.FileExists("server\server.cjs") Then
    appDir = fso.GetAbsolutePathName(".")
ElseIf fso.FileExists(WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\ProjectNexus\server\server.cjs") Then
    appDir = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\ProjectNexus"
ElseIf fso.FileExists(WshShell.ExpandEnvironmentStrings("%USERPROFILE%") & "\Downloads\dsa\server\server.cjs") Then
    appDir = WshShell.ExpandEnvironmentStrings("%USERPROFILE%") & "\Downloads\dsa"
End If

If appDir <> "" Then
    WshShell.CurrentDirectory = appDir
End If

' 1. Start Backend Server silently (0 = hidden window)
WshShell.Run "cmd /c node server\server.cjs", 0, False

' 2. Start Vite Dev Server silently (0 = hidden window)
WshShell.Run "cmd /c npx vite --port 5173", 0, False

' 3. Wait for server readiness
WScript.Sleep 1500

' 4. Launch in Native App Window (Edge App Mode or default browser)
On Error Resume Next
WshShell.Run "msedge.exe --app=http://localhost:5173", 1, False
If Err.Number <> 0 Then
    WshShell.Run "http://localhost:5173", 1, False
End If
